student = { "name": "Luca",
            "age": 17,
            "class": "3A",
            "average": 7.5
            }

print(f'student name: {student["name"]}')
print(f'Student age: {student["age"]}')
print(f'Average : {student["average"]}')

print(f'the student {student["name"]} goes in class {student["class"]} and his maks average is {student["average"]}')

student = { "name": "Luca",
            "age": 17,
            "class": "3A",
            "average": 7.5
            }

student["average"] = 8
student["passed"] = True

print(student)

print("is there any 'address' key? ", "address" in student)